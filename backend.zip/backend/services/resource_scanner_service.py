class ResourceScannerService:
    """Build a global-resource style scan from the idea profile and similarity matches."""

    def scan(self, idea_profile: dict, similarity_matches: list[dict], mode: str) -> dict[str, list[dict]]:
        """Return grouped resources that feel like patents, papers, startups, and technologies."""
        industry = str(idea_profile.get("industry", "AI")).lower()
        stack = idea_profile.get("technology_stack", [])
        primary_tech = stack[0] if stack else "AI / NLP"

        patents = [
            {
                "title": f"{industry.title()} decision support system for {primary_tech.lower()} workflows",
                "source": "Patent Knowledge Graph",
                "link": f"https://patents.google.com/?q={industry.replace(' ', '+')}+{primary_tech.replace(' ', '+')}",
                "relevance": 72,
            },
            {
                "title": f"Automated similarity scoring and innovation benchmarking for {industry.title()} ideas",
                "source": "Patent Landscape",
                "link": "https://patents.google.com/",
                "relevance": 67,
            },
        ]

        research = [
            {
                "title": f"Semantic retrieval systems for {industry.title()} product discovery",
                "source": "Research Archive",
                "link": "https://arxiv.org/",
                "relevance": 76,
            },
            {
                "title": f"Applied {primary_tech} evaluation frameworks for innovation teams",
                "source": "Scholarly Search",
                "link": "https://scholar.google.com/",
                "relevance": 71,
            },
        ]

        startups = [
            {
                "title": match["title"],
                "source": match["source"],
                "link": "https://www.crunchbase.com/",
                "relevance": round(float(match["similarity_score"]), 2),
            }
            for match in similarity_matches[:3]
        ]

        if not startups:
            startups = [
                {
                    "title": f"{industry.title()} intelligence cloud",
                    "source": "Startup Database",
                    "link": "https://www.crunchbase.com/",
                    "relevance": 64,
                }
            ]

        related_technologies = [
            {"name": primary_tech, "fit": 91},
            {"name": "Vector Search", "fit": 87},
            {"name": "Workflow Analytics", "fit": 82},
            {"name": "Secure Collaboration", "fit": 79},
        ]

        if mode == "hackathon":
            related_technologies.append({"name": "Rapid prototyping APIs", "fit": 77})
        else:
            related_technologies.append({"name": "Enterprise integration layer", "fit": 80})

        return {
            "similar_patents": patents,
            "similar_research": research,
            "similar_startups": startups,
            "related_technologies": related_technologies,
        }
